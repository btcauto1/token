# BTC.auto

**BTC.auto** is a decentralized cryptocurrency token designed to bring
Bitcoin-style value storage into the modern Web3 and DeFi ecosystem.

## Overview

BTC.auto is an EVM-compatible token deployed on a smart contract
blockchain network (such as BNB Smart Chain). The token allows users to
store, transfer, and trade value directly without banks or
intermediaries.

## Token Information

-   Name: BTC.auto
-   Symbol: BTC.auto
-   Standard: BEP-20 Compatible
-   Decimals: 6
-   Total Supply: 2,600,000
-   Network: EVM Compatible Network

## Features

-   Decentralized peer-to-peer transfers
-   Transparent blockchain transactions
-   Secure smart-contract execution
-   DeFi and DEX compatibility

## Security

Never share your private keys or seed phrase. The team cannot recover
lost wallets.
