# Contributing to BTC.auto

Thank you for your interest in contributing to BTC.auto!

## How to Contribute

1.  Fork the repository
2.  Create a new branch (feature/your-feature-name)
3.  Commit your changes
4.  Push to your fork
5.  Open a Pull Request

## Guidelines

-   Follow clean coding practices
-   Keep commits descriptive
-   Test smart contract changes before submitting
-   Do not include private keys or sensitive data

## Reporting Issues

If you discover a bug or vulnerability, please open an issue in the
repository.
